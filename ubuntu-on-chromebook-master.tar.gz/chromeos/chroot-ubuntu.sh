#!/bin/bash

source /etc/uoc-config

chroot $MP
