#!/bin/bash

source config

chroot $MP
