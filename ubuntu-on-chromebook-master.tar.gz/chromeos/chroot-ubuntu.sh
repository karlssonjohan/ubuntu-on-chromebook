#!/bin/bash

source /usr/local/etc/uoc-config

chroot $MP
