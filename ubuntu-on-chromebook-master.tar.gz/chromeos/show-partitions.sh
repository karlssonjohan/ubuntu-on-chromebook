#!/bin/bash

cgpt show /dev/mmcblk0
