#!/bin/bash

source /etc/uoc-config

cgpt show $DISK
