#!/bin/bash

source /usr/local/etc/uoc-config

cgpt show $DISK
